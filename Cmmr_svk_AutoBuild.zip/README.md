# 🤖 Cmmr-svk AutoBuild

Bu proje, GitHub Actions üzerinden **otomatik APK oluşturma ve release yükleme** desteğine sahiptir.

## 🚀 Kullanım
1. Bu klasörü GitHub'da `Cmmr-svk` adında bir depoya yükle (`muammeruyanik80-cpu/Cmmr-svk`).
2. GitHub'da repo ayarlarından:
   - Settings → Actions → General → "Allow all actions" seçeneği aktif olmalı.
3. Actions sekmesine git → “Build & Release APK” → “Run workflow” de.

## 📦 Sonuç
Derleme tamamlandığında:
- `Cmmr.apk` dosyası otomatik olarak **Releases** sekmesine eklenecektir.
- Telefona indirip test amaçlı yükleyebilirsin (Debug APK).

